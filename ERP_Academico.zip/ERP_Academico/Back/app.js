const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'front')));
app.set('view engine', 'ejs'); 
app.set('views', path.join(__dirname, 'views'));



const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', 
  database: 'nomina_db',
  port: 3306
});

db.connect((err) => {
  if (err) throw err;
  console.log('✅ Conectado a la base de datos');
});


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'front', 'formulario.html'));
});

app.post('/guardar', (req, res) => {
  const datos = req.body;

  const sql = 'INSERT INTO personal SET ?';
  db.query(sql, datos, (err, result) => {
    if (err) return res.status(500).send('Error en DB');

    
    const linea = `${datos.nombre},${datos.cargo},${datos.tipo_contrato},${datos.duracion_contrato},${datos.fecha_inicio},${datos.fecha_fin},${datos.salario_mensual},${datos.auxilio_transporte}\n`;
    fs.appendFile('datos.txt', linea, (err) => {
      if (err) return res.status(500).send('Error en archivo');
      res.redirect('/registros');
    });
  });
});


app.get('/registros', (req, res) => {
  db.query('SELECT * FROM personal', (err, results) => {
    if (err) return res.status(500).send('Error mostrando registros');
    res.render('tabla', { registros: results });
  });
});


app.get('/eliminar/:id', (req, res) => {
  const id = req.params.id;
  db.query('DELETE FROM personal WHERE id = ?', [id], (err, result) => {
    if (err) return res.status(500).send('Error eliminando');
    res.redirect('/registros');
  });
});


app.get('/editar/:id', (req, res) => {
  const id = req.params.id;
  db.query('SELECT * FROM personal WHERE id = ?', [id], (err, results) => {
    if (err || results.length === 0) return res.status(404).send('No encontrado');
    res.render('editar', { datos: results[0] });
  });
});


app.post('/actualizar/:id', (req, res) => {
  const id = req.params.id;
  const nuevosDatos = req.body;
  db.query('UPDATE personal SET ? WHERE id = ?', [nuevosDatos, id], (err, result) => {
    if (err) return res.status(500).send('Error actualizando');
    res.redirect('/registros');
  });
});


app.listen(3000, () => {
  console.log('🚀 Servidor en http://localhost:3000');
});


app.get('/listar', (req, res) => {
  db.query('SELECT * FROM personal', (err, results) => {
    if (err) {
      console.error('❌ Error al obtener los datos:', err);
      return res.status(500).send('Error consultando los datos');
    }
    res.json(results);
  });
});
